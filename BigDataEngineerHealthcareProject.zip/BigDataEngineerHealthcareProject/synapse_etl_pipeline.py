from azure.synapse.artifacts import ArtifactsClient
from azure.identity import DefaultAzureCredential

# Initialize the Azure Synapse client
def initialize_synapse_client(workspace_name, resource_group_name):
    credential = DefaultAzureCredential()
    client = ArtifactsClient(credential, subscription_id="<your_subscription_id>")
    return client

# Example to trigger an ETL pipeline
def trigger_etl_pipeline(client, pipeline_name):
    run_response = client.pipeline_runs.create_run(
        resource_group_name="<your_resource_group>",
        workspace_name="<your_workspace>",
        pipeline_name=pipeline_name
    )
    return run_response

# Example usage
synapse_client = initialize_synapse_client("<workspace_name>", "<resource_group_name>")
run_response = trigger_etl_pipeline(synapse_client, "ehr_etl_pipeline")
print(run_response)
