from sklearn.model_selection import train_test_split

def prepare_ml_dataset(data_frame):
    features = data_frame[['age', 'blood_pressure', 'heart_rate']]
    target = data_frame['disease_outcome']  # 1 for disease, 0 for no disease
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2)
    return X_train, X_test, y_train, y_test

# Example usage
X_train, X_test, y_train, y_test = prepare_ml_dataset(patient_data)
