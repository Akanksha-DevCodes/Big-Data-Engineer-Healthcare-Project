from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

# Initialize Key Vault Client
def get_secret_from_key_vault(vault_url, secret_name):
    client = SecretClient(vault_url=vault_url, credential=DefaultAzureCredential())
    secret = client.get_secret(secret_name)
    return secret.value

# Example usage
vault_url = "https://<your-keyvault-name>.vault.azure.net/"
secret_name = "patient-record-encryption-key"
encryption_key = get_secret_from_key_vault(vault_url, secret_name)
print(f"Retrieved Encryption Key: {encryption_key}")
