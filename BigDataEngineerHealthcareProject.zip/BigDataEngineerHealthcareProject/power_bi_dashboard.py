import pandas as pd
import matplotlib.pyplot as plt
from azure.identity import DefaultAzureCredential
from azure.monitor.query import MetricsQueryClient
from azure.monitor.query.models import MetricAggregationType

# Authenticate and create a MetricsQueryClient
credential = DefaultAzureCredential()
client = MetricsQueryClient(credential)

def get_health_metrics(resource_id):
    metrics_data = client.query(
        resource_id,
        timespan="PT1H",
        metric_names=["HeartRate", "BloodPressure", "Temperature"],
        aggregation=MetricAggregationType.AVERAGE
    )
    return metrics_data

# Example usage
resource_id = "<your_resource_id>"
metrics = get_health_metrics(resource_id)

# Create a simple plot from the data
df = pd.DataFrame(metrics)
df.plot(kind="line")
plt.title("Real-Time Health Metrics")
plt.show()
