import hl7

# Parse HL7 message
def parse_hl7_message(message):
    parsed_message = hl7.parse(message)
    return parsed_message

# Example HL7 message
hl7_message = "MSH|^~\&|HIS|RIH|EKG|EKG|202503261200||ADT^A01|MSG00001|P|2.3"
parsed_message = parse_hl7_message(hl7_message)

# Extract specific segments
patient_id = parsed_message.segment('PID')[3]
print(f"Patient ID: {patient_id}")
