import pyodbc

def migrate_to_sql_server():
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                          'SERVER=<your_sql_server>;'
                          'DATABASE=<your_database>;'
                          'UID=<your_username>;'
                          'PWD=<your_password>')
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM old_table")
    
    for row in cursor.fetchall():
        cursor.execute("INSERT INTO new_table VALUES (?, ?, ?)", row)
    
    conn.commit()

# Example usage
migrate_to_sql_server()
