from azure.storage.filedatalake import DataLakeServiceClient

def initialize_adls_client(account_name, account_key):
    service_client = DataLakeServiceClient(account_url=f"https://{account_name}.dfs.core.windows.net", credential=account_key)
    return service_client

def create_container(service_client, container_name):
    file_system_client = service_client.create_file_system(file_system=container_name)
    return file_system_client

# Example usage
account_name = "<your_account_name>"
account_key = "<your_account_key>"
container_name = "ehr-container"

service_client = initialize_adls_client(account_name, account_key)
container = create_container(service_client, container_name)
