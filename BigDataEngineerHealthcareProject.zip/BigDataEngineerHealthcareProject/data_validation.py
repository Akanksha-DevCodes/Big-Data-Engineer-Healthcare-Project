import pandas as pd

def validate_patient_data(data_frame):
    errors = []
    if data_frame['age'].isnull().any():
        errors.append("Missing age data")
    if not data_frame['patient_id'].apply(lambda x: isinstance(x, int)).all():
        errors.append("Invalid patient_id format")
    if data_frame['blood_pressure'].max() > 180:  # Anomaly threshold
        errors.append("Blood pressure exceeds normal range")
    
    return errors

# Example usage
patient_data = pd.read_csv("patient_records.csv")
validation_errors = validate_patient_data(patient_data)

if validation_errors:
    for error in validation_errors:
        print(f"Validation Error: {error}")
else:
    print("All data is valid!")
